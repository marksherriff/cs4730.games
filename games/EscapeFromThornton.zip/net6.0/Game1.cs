﻿using System;
using System.Collections.Generic;
using System.IO;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Level_1;

using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Media;
using System.Linq; //this will come in later
using System.Numerics;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Xml.Linq;
using TiledCS;

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    private CollisionHandler _collisionHandler;
    private Point GameBounds; //window resolution
    private Point SpriteSize = new Point(75, 55);
    // NEED TO MODIFY BASED ON SCALE BETWEEN TILESHEET AND DRAWING
    private float tileScale = 2f;
    private int tileSpriteSize = 32;
    private int TileSize;

    // Entities with physics
    private Player Sprite;
    private Box box;
    private int coinsCollected = 0;
    // 1 for down, -1 for up (multiplies with entity's gravity)
    private int levelGravity = 1;

    // Graphics
    private Texture2D Texture;
    private Texture2D PlayerSheet;
    private Texture2D TileSheet;
    private Texture2D SpikeSheet;
    private Texture2D BoxSprite;
    private Rectangle[] spikes = new Rectangle[4];
    private SpriteFont hudFont;
    private SpriteFont levelSelectFont;

    // Player inputs
    private KeyboardState keyboardState;
    private MouseState mouseState;
    private String mouseTarget = "";
    private bool tryFlip = false;
    private Rectangle level1Button = new Rectangle(360, 330, 160, 50);
    private Rectangle level2Button = new Rectangle(760, 330, 160, 50);
    private Rectangle level3Button = new Rectangle(1160, 330, 160, 50);
    private Rectangle level4Button = new Rectangle(360, 430, 160, 50);
    private Rectangle level5Button = new Rectangle(760, 430, 160, 50);
    private Rectangle MainQuitButton = new Rectangle(760, 500, 160, 50); // for quitting the game from the main menu

    private Rectangle resumeButton;
    private Rectangle restartButton;
    private Rectangle quitButton;

    private string levelLoaded = "";
    private bool paused = false;
    private bool prevEscapeDown = false;
    private bool prevPause = false;
    private bool prevRDown = false;
    private bool prevYDown = false;

    // initialize the tiled map
    private TiledMap map;
    private Dictionary<int, TiledTileset> tilesets;
    private Texture2D tilesetTexture;
    private Texture2D spikeTexture;
    private TiledLayer solidLayer;
    private TiledLayer platformLayer;
    private TiledLayer goalLayer;
    private TiledLayer coinLayer;
    private TiledLayer gravityUpLayer;
    private TiledLayer gravityUpColorLayer;
    private TiledLayer gravityDownLayer;
    private TiledObject playerSpawn;
    private bool flippable;
    private TiledObject boxSpawn;
    private TiledLayer spikeLayer;
    private TiledLayer switchLayer;
    private TiledLayer doorLayer;
    // switch boolean
    public static bool switchOn = false;

    // initialize sound effects
    private Song music;
    private SoundEffect jump;
    private SoundEffect flipUp;
    private SoundEffect flipDown;
    private SoundEffect footstep;
    private SoundEffect impact;

    // controller controls cursor inputs
    private int horizontalSpeed = 10;
    private int verticalSpeed = -10;

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        GameBounds = new Point((int)(25 * tileSpriteSize * tileScale), (int)(15 * tileSpriteSize * tileScale));
        _graphics.PreferredBackBufferWidth = GameBounds.X;
        _graphics.PreferredBackBufferHeight = GameBounds.Y;
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        TileSize = (int)(tileSpriteSize * tileScale);
    }

    protected override void Initialize()
    {
        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        // Load fonts
        hudFont = Content.Load<SpriteFont>("Fonts/Hud");
        levelSelectFont = Content.Load<SpriteFont>("Fonts/LevelSelect");
        BoxSprite = Content.Load<Texture2D>("spritesheets/BoxSprite");

        Microsoft.Xna.Framework.Vector2 textDim = levelSelectFont.MeasureString("Resume");
        resumeButton = new Rectangle((int)(GameBounds.X / 2 - textDim.X / 2 - 10), 350, (int)textDim.X + 20, (int)textDim.Y + 20);
        textDim = levelSelectFont.MeasureString("Restart");
        restartButton = new Rectangle((int)(GameBounds.X / 2 - textDim.X / 2 - 10), 450, (int)textDim.X + 20, (int)textDim.Y + 20);
        textDim = levelSelectFont.MeasureString("Quit To Menu");
        quitButton = new Rectangle((int)(GameBounds.X / 2 - textDim.X / 2 - 10), 550, (int)textDim.X + 20, (int)textDim.Y + 20);

        // Load sounds
        music = Content.Load<Song>("Audio/Mission Plausible");
        jump = Content.Load<SoundEffect>("Audio/phaseJump1");
        flipUp = Content.Load<SoundEffect>("Audio/phaserUp4");
        flipDown = Content.Load<SoundEffect>("Audio/phaserDown3");
        footstep = Content.Load<SoundEffect>("Audio/footstep_concrete_000");
        impact = Content.Load<SoundEffect>("Audio/impactSoft_medium_001");

        Reset();
    }

    protected override void Update(GameTime gameTime)
    {

        GamePadState state = new GamePadState();

        // check controller support
        GamePadCapabilities capabilities = GamePad.GetCapabilities(PlayerIndex.One);
        if (capabilities.IsConnected == true)
        {
            state = GamePad.GetState(PlayerIndex.One);
        }
        // Only accepts input on press and release
        if ((prevEscapeDown && !Keyboard.GetState().IsKeyDown(Keys.Escape)) || (prevPause && !state.IsButtonDown(Buttons.Start)))
        {
            // Pause menu only works in a level
            if (!levelLoaded.Equals(""))
                paused = !paused;
            prevEscapeDown = false;
            prevPause = false;
        }
        else
        {
            prevEscapeDown = Keyboard.GetState().IsKeyDown(Keys.Escape);
            prevPause = state.IsButtonDown(Buttons.Start);
        }

        HandleInput(gameTime);
        // No physics when not in level
        if (levelLoaded.Equals("") || paused)
        {
            return;
        }

        Rectangle objRect;
        Rectangle playerRect = Sprite.getBoundingBox();
        Rectangle boxRect = box.getBoundingBox();

        // Player cannot flip inside of a gravity field
        foreach (var obj in gravityUpLayer.objects)
        {
            objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            if (playerRect.Intersects(objRect))
                tryFlip = false;
        }

        foreach (var obj in gravityDownLayer.objects)
        {
            objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            if (playerRect.Intersects(objRect))
                tryFlip = false;
        }

        // Flips gravity
        if (tryFlip)
        {
            levelGravity *= -1;
            tryFlip = false;
            if (levelGravity == 1)
            {
                flipUp.Play();
            }
            if (levelGravity == -1)
            {
                flipDown.Play();
            }
        }

        // Set gravity to the level's
        Sprite.setGravity(levelGravity);
        box.setGravity(levelGravity);

        // Gravity fields overrides the level's gravity
        // TODO: only apply if majority of player is intersecting?
        foreach (var obj in gravityUpLayer.objects)
        {
            objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            if (playerRect.Intersects(objRect))
                Sprite.setGravity(-1);
            if (boxRect.Intersects(objRect))
                box.setGravity(-1);
        }

        foreach (var obj in gravityDownLayer.objects)
        {
            objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            if (playerRect.Intersects(objRect))
                Sprite.setGravity(1);
            if (boxRect.Intersects(objRect))
                box.setGravity(1);
        }

        foreach (var obj in spikeLayer.objects)
        {
            objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            if (playerRect.Intersects(objRect))
                Reset();
        }

        // Needs to check/update entities before collision detection, which "corrects" them
        // Updating afterwards means movement is calculated for player so they are "falling" on ground/platform
        Sprite.Update(gameTime, keyboardState, box);
        box.ApplyPhysics(gameTime);

        //_collisionHandler.CheckCollisions(gameTime);
        // Check player ground collision
        CheckLayer(gameTime, solidLayer, "Solid");
        CheckLayer(gameTime, platformLayer, "Platform");

        // CollisionHandler exits game, so we're doing a separate check for now to avoid passing things back and forth
        // CheckLayer(gameTime, goalLayer, "Goal");
        foreach (var obj in goalLayer.objects)
        {
            objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));
            if (playerRect.Intersects(objRect))
            {
                levelLoaded = obj.name;
                if (levelLoaded == "menu")
                {
                    paused = false;
                    levelLoaded = "";
                    MediaPlayer.Stop();
                }
                else
                {
                    LoadLevel(levelLoaded);
                }
            }
        }


        // Checks for collision between player and box
        // Checking before prevents clipping into level
        // Checking after prevents jittering when standing on box
        boxRect = box.getBoundingBox();
        if (playerRect.Intersects(boxRect))
        {
            _collisionHandler.OnCollisionBetween(gameTime, Sprite, playerRect, box, boxRect);
        }

        // Krutik addition to check if switch on or off and detect collisions for each case
        switchOn = false;
        //CheckLayer(gameTime, switchLayer, "Switch");
        foreach (var obj in switchLayer.objects)
        {
            // for every switch, check if box intersects with it to 'flip' the switch
            Rectangle newRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));
            if (boxRect.Intersects(newRect))
            {
                switchOn = true;

            }
            else
            {
                switchOn = false;
            }
        }
        // if switch is off, then player collides with the 'door' as if it is a solid object
        if (switchOn == false)
        {
            // for every door in level, check collisions as if it is a solid object
            foreach (var obj in doorLayer.objects)
            {
                Rectangle newRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));
                _collisionHandler.CheckCollisions(gameTime, newRect, "Door");
            }
        }
        // end Krutik addition

        // Only need to get once since coins don't move player
        playerRect = Sprite.getBoundingBox();
        foreach (var obj in coinLayer.objects)
        {
            objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            if (obj.name.Equals("Coin") && playerRect.Intersects(objRect))
            {
                // once a collision has been detected, no need to check the other objects
                var layer = map.Layers.First(x => x.type == TiledLayerType.TileLayer);
                layer.data[(objRect.Y / TileSize) * layer.width + (objRect.X / TileSize)] = 0;
                obj.name = "";
                coinsCollected += 1;
                break;
            }
        }

        base.Update(gameTime);
    }

    // Reusable function for simple collision check with terrain
    private void CheckLayer(GameTime gameTime, TiledLayer layer, String type)
    {
        foreach (var obj in layer.objects)
        {
            Rectangle objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));
            _collisionHandler.CheckCollisions(gameTime, objRect, type);
        }
    }

    private void HandleInput(GameTime gameTime)
    {
        GamePadState state = new GamePadState();

        // check controller support
        GamePadCapabilities capabilities = GamePad.GetCapabilities(PlayerIndex.One);
        if (capabilities.IsConnected == true)
        {
            state = GamePad.GetState(PlayerIndex.One);
        }

        // Player use mouse to choose level
        if (levelLoaded.Equals("")) {
            mouseState = Mouse.GetState();

            Point mousePosition = new Point(mouseState.X, mouseState.Y);
            
            //manipulate mouse with controller
            if (state.IsButtonDown(Buttons.LeftThumbstickUp) || state.IsButtonDown(Buttons.DPadUp))
            {
                Mouse.SetPosition(mouseState.X, mouseState.Y + verticalSpeed);
            }
            if (state.IsButtonDown(Buttons.LeftThumbstickDown) || state.IsButtonDown(Buttons.DPadDown))
            {
                Mouse.SetPosition(mouseState.X, mouseState.Y - verticalSpeed);
            }
            if (state.IsButtonDown(Buttons.LeftThumbstickLeft) || state.IsButtonDown(Buttons.DPadLeft))
            {
                Mouse.SetPosition(mouseState.X - horizontalSpeed, mouseState.Y);
            }
            if (state.IsButtonDown(Buttons.LeftThumbstickRight) || state.IsButtonDown(Buttons.DPadRight))
            {
                Mouse.SetPosition(mouseState.X + horizontalSpeed, mouseState.Y);
            }
            // Recognize a single click of the left mouse button
            if (mouseState.LeftButton == ButtonState.Pressed || state.IsButtonDown(Buttons.A))
            {
                if (level1Button.Contains(mousePosition))
                {
                    mouseTarget = "level_1";
                }
                else if (level2Button.Contains(mousePosition))
                {
                    mouseTarget = "level_2";
                }
                else if (level3Button.Contains(mousePosition))
                {
                    mouseTarget = "level_3";
                }
                else if (level4Button.Contains(mousePosition))
                {
                    mouseTarget = "level_4";
                }
                else if (level5Button.Contains(mousePosition))
                {
                    mouseTarget = "level_5";
                }
                else if (MainQuitButton.Contains(mousePosition))
                {
                    mouseTarget = "main_quit";
                }
            }
            else if (mouseState.LeftButton == ButtonState.Released || state.IsButtonUp(Buttons.A))
            {
                if (mouseTarget.Equals("level_1") && level1Button.Contains(mousePosition))
                {
                    levelLoaded = "level_1";
                    LoadLevel("level_1");
                }
                else if (mouseTarget.Equals("level_2") && level2Button.Contains(mousePosition))
                {
                    levelLoaded = "level_2";
                    LoadLevel("level_2");
                }
                else if (mouseTarget.Equals("level_3") && level3Button.Contains(mousePosition))
                {
                    levelLoaded = "level_3";
                    LoadLevel("level_3");
                }
                else if (mouseTarget.Equals("level_4") && level4Button.Contains(mousePosition))
                {
                    levelLoaded = "level_4";
                    LoadLevel("level_4");
                }
                else if (mouseTarget.Equals("level_5") && level5Button.Contains(mousePosition))
                {
                    levelLoaded = "level_5";
                    LoadLevel("level_5");
                }
                else if (mouseTarget.Equals("main_quit") && MainQuitButton.Contains(mousePosition))
                {
                    Exit();
                }
                mouseTarget = "";
            }
            return;
        }
        // Take inputs for the buttons on the pause menu
        else if (paused)
        {
            mouseState = Mouse.GetState();

            Point mousePosition = new Point(mouseState.X, mouseState.Y);

            if (state.IsButtonDown(Buttons.LeftThumbstickUp) || state.IsButtonDown(Buttons.DPadUp)) 
            {
                Mouse.SetPosition(mouseState.X, mouseState.Y + verticalSpeed);
            }
            if (state.IsButtonDown(Buttons.LeftThumbstickDown) || state.IsButtonDown(Buttons.DPadDown)) 
            {
                Mouse.SetPosition(mouseState.X, mouseState.Y - verticalSpeed);
            }
            if (state.IsButtonDown(Buttons.LeftThumbstickLeft) || state.IsButtonDown(Buttons.DPadLeft))
            {
                Mouse.SetPosition(mouseState.X - horizontalSpeed, mouseState.Y);
            }
            if (state.IsButtonDown(Buttons.LeftThumbstickRight) || state.IsButtonDown(Buttons.DPadRight))
            {
                Mouse.SetPosition(mouseState.X + horizontalSpeed, mouseState.Y);
            }
            if (mouseState.LeftButton == ButtonState.Pressed || state.IsButtonDown(Buttons.A))
            {
                if (resumeButton.Contains(mousePosition))
                {
                    mouseTarget = "resume";
                }
                else if (restartButton.Contains(mousePosition))
                {
                    mouseTarget = "restart";
                }
                else if (quitButton.Contains(mousePosition))
                {
                    mouseTarget = "quit";
                }
            }
            else if (mouseState.LeftButton == ButtonState.Released || state.IsButtonUp(Buttons.A))
            {
                if (mouseTarget.Equals("resume") && resumeButton.Contains(mousePosition))
                {
                    paused = false;
                }
                else if (mouseTarget.Equals("restart") && restartButton.Contains(mousePosition))
                {
                    paused = false;
                    LoadLevel(levelLoaded);
                }
                else if (mouseTarget.Equals("quit") && quitButton.Contains(mousePosition))
                {
                    paused = false;
                    levelLoaded = "";
                    MediaPlayer.Stop();
                }
                mouseTarget = "";
            }
        }

        // get all of our input states
        keyboardState = Keyboard.GetState();

        // Player action, flips the level's gravity (including the vase)
        // Activates flag to try to flip
        if (flippable && (keyboardState.IsKeyDown(Keys.Space) || state.IsButtonDown(Buttons.RightTrigger)) && Sprite.Velocity.Y == 0)
            tryFlip = true;

        // checking for restart hotkey input
        if ((!keyboardState.IsKeyDown(Keys.R) && prevRDown) || (!state.IsButtonDown(Buttons.Y) && prevYDown))
        {
            prevRDown = false;
            prevYDown = false;
            Reset();
        }
        else
        {
            prevRDown = keyboardState.IsKeyDown(Keys.R);
            prevYDown = state.IsButtonDown(Buttons.Y);
        }
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.CornflowerBlue);

        _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp);

        // Draws the level selector
        if (levelLoaded.Equals(""))
        {
            //DrawShadowedString(levelSelectFont, "Choose a level!", new Vector2(600, 150), Color.Black);
            _spriteBatch.DrawString(levelSelectFont, "Select a level!",
                new Vector2(GameBounds.X / 2 - levelSelectFont.MeasureString("PAUSED").X / 2, 150), Color.Black);

            Vector2 position = new Vector2(level1Button.X, level1Button.Y);
            _spriteBatch.Draw(Texture, position, level1Button,
                Color.White,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);

            DrawShadowedString(levelSelectFont, "Level 1", new Vector2(position.X + 10, position.Y), Color.Black);

            position = new Vector2(level2Button.X, level2Button.Y);
            _spriteBatch.Draw(Texture, position, level2Button,
                Color.White,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);

            DrawShadowedString(levelSelectFont, "Level 2", new Vector2(position.X + 10, position.Y), Color.Black);

            position = new Vector2(level3Button.X, level3Button.Y);
            _spriteBatch.Draw(Texture, position, level3Button,
                Color.White,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);

            DrawShadowedString(levelSelectFont, "Level 3", new Vector2(position.X + 10, position.Y), Color.Black);

            position = new Vector2(level4Button.X, level4Button.Y);
            _spriteBatch.Draw(Texture, position, level4Button,
                Color.White,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);

            DrawShadowedString(levelSelectFont, "Level 4", new Vector2(position.X + 10, position.Y), Color.Black);

            position = new Vector2(level5Button.X, level5Button.Y);
            _spriteBatch.Draw(Texture, position, level5Button,
                Color.White,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);

            DrawShadowedString(levelSelectFont, "Level 5", new Vector2(position.X + 10, position.Y), Color.Black);

            position = new Vector2(MainQuitButton.X, MainQuitButton.Y);
            _spriteBatch.Draw(Texture, position, MainQuitButton,
                Color.White,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);

            DrawShadowedString(levelSelectFont, "  Quit", new Vector2(position.X + 10, position.Y), Color.Black);

            //Keyboard Controls
            DrawShadowedString(hudFont, "Keyboard Controls", new Vector2(250, 600), Color.White);
            DrawShadowedString(hudFont, "W to Jump", new Vector2(250, 620), Color.White);
            DrawShadowedString(hudFont, "A to Move Left", new Vector2(250, 640), Color.White);
            DrawShadowedString(hudFont, "D to Move Right", new Vector2(250, 660), Color.White);
            DrawShadowedString(hudFont, "R to Restart a Level", new Vector2(250, 680), Color.White);
            DrawShadowedString(hudFont, "ESC to Pause", new Vector2(250, 700), Color.White);
            DrawShadowedString(hudFont, "Mouse + Left Click to Navigate Menus", new Vector2(250, 720), Color.White);

            DrawShadowedString(hudFont, "Gamepad Controls", new Vector2(850, 600), Color.White);
            DrawShadowedString(hudFont, "A, D-Pad Up, or Left Joystick Up to Jump", new Vector2(850, 620), Color.White);
            DrawShadowedString(hudFont, "D-Pad Left or Left Joystick Left to Move Left", new Vector2(850, 640), Color.White);
            DrawShadowedString(hudFont, "D-Pad Right or Left Joystick Right to Move Right", new Vector2(850, 660), Color.White);
            DrawShadowedString(hudFont, "Y to Restart a Level", new Vector2(850, 680), Color.White);
            DrawShadowedString(hudFont, "Start to Pause", new Vector2(850, 700), Color.White);
            DrawShadowedString(hudFont, "Left Joystick + A to Navigate Menus", new Vector2(850, 720), Color.White);

            _spriteBatch.End();
            return;
        }

        // TODO: decide which sprite and add
        var tileLayers = map.Layers.Where(x => x.type == TiledLayerType.TileLayer);
        foreach (var layer in tileLayers)
        {
            for (var y = 0; y < layer.height; y++)
            {
                for (var x = 0; x < layer.width; x++)
                {
                    // Assuming the default render order is used which is from right to bottom
                    var index = (y * layer.width) + x;
                    var gid = layer.data[index]; // The tileset tile index
                    var tileX = x * TileSize;
                    var tileY = y * TileSize;

                    // Gid 0 is used to tell there is no tile set
                    if (gid == 0)
                    {
                        continue;
                    }

                    // Helper method to fetch the right TieldMapTileset instance
                    // This is a connection object Tiled uses for linking the correct tileset to the 
                    // gid value using the firstgid property
                    var mapTileset = map.GetTiledMapTileset(gid);

                    // Retrieve the actual tileset based on the firstgid property of the connection object 
                    // we retrieved just now
                    var tileset = tilesets[mapTileset.firstgid];

                    // Use the connection object as well as the tileset to figure out the source rectangle
                    var rect = map.GetSourceRect(mapTileset, tileset, gid);

                    // Create destination and source rectangles
                    var source = new Rectangle(rect.x, rect.y, rect.width, rect.height);
                    var destination = new Rectangle(tileX, tileY, TileSize, TileSize);


                    // Render sprite at position tileX, tileY using the rect
                    _spriteBatch.Draw(spikeTexture, destination, source, Color.White,
    0, Vector2.Zero, SpriteEffects.None, 0);
                    _spriteBatch.Draw(tilesetTexture, destination, source, Color.White,
                        0, Vector2.Zero, SpriteEffects.None, 0);
                }
            }
        }

        // Draws the gravity field
        // Red up field
        foreach (var obj in gravityUpColorLayer.objects)
        {
            Rectangle objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            _spriteBatch.Draw(Texture, new Vector2(objRect.X, objRect.Y), objRect,
                Color.Red * 0.2f,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);
        }
        // Blue down field
        foreach (var obj in gravityDownLayer.objects)
        {
            Rectangle objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            _spriteBatch.Draw(Texture, new Vector2(objRect.X, objRect.Y), objRect,
                Color.Blue * 0.2f,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);
        }

        // Spikes
        foreach (var obj in spikeLayer.objects)
        {
            Rectangle objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));
        }

        // Door and Switch
        // switch changes from 
        foreach (var obj in switchLayer.objects)
        {
            Rectangle objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            if (switchOn == false)
            {
                _spriteBatch.Draw(Texture, new Vector2(objRect.X, objRect.Y), objRect,
                Color.Red * 0.2f,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);
            }
            else
            {
                _spriteBatch.Draw(Texture, new Vector2(objRect.X, objRect.Y), objRect,
                Color.Green * 0.2f,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);
            }

        }

        // door changes from red to blue color
        foreach (var obj in doorLayer.objects)
        {
            Rectangle objRect = new Rectangle((int)(obj.x * tileScale), (int)(obj.y * tileScale), (int)(obj.width * tileScale), (int)(obj.height * tileScale));

            if (switchOn == false)
            {
                _spriteBatch.Draw(Texture, new Vector2(objRect.X, objRect.Y), objRect,
                Color.Red * 0.8f,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);
            }
            else
            {
                _spriteBatch.Draw(Texture, new Vector2(objRect.X, objRect.Y), objRect,
                Color.Green * 0.2f,
                0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);
            }

        }

        // Draws the box/vase
        _spriteBatch.Draw(BoxSprite, box.Position, box.spriteBounds,
                                    Color.White,
                                    0, Vector2.Zero, tileScale * 3 / 4,
                                    SpriteEffects.None, 0.00001f);

        // Draws the player
        Sprite.Draw(gameTime, _spriteBatch);

        //DrawShadowedString(hudFont, "Coins: " + coinsCollected, new Vector2(50, 50), Color.Yellow);
        //_spriteBatch.DrawString(hudFont, "Coins: " + coinsCollected, new Microsoft.Xna.Framework.Vector2(400, 100), Color.Black);
        if (levelLoaded.Equals("level_3"))
        {
            DrawShadowedString(hudFont, "Remember to restart if you're stuck", new Vector2(50, 150), Color.White);
            DrawShadowedString(hudFont, "Looks you need to get higher to fall through the field", new Vector2(1000, 600), Color.White);
            DrawShadowedString(hudFont, "Maybe that box could help...", new Vector2(1000, 650), Color.White);
        }
        if (levelLoaded.Equals("level_4"))
        {
            DrawShadowedString(hudFont, "Press SPACE or RIGHT TRIGGER to flip gravity while on ground", new Vector2(50, 850), Color.White);
            DrawShadowedString(hudFont, "AND not in a field", new Vector2(50, 880), Color.White);
            DrawShadowedString(hudFont, "This door seems to be linked to something", new Vector2(1200, 840), Color.White);
        }

        if (paused)
        {
            // Translucent screen to make game faded
            _spriteBatch.Draw(Texture, new Vector2(0, 0), new Rectangle(0, 0, GameBounds.X, GameBounds.Y),
            Color.Black * 0.5f,
            0, Vector2.Zero, 1.0f,
                SpriteEffects.None, 0.00001f);

            // Title showing the game is paused
            _spriteBatch.DrawString(levelSelectFont, "PAUSED",
                new Vector2(GameBounds.X / 2 - levelSelectFont.MeasureString("PAUSED").X / 2, 200), Color.White);

            // Buttons in pause menu
            DrawButton(levelSelectFont, "Resume", resumeButton);

            DrawButton(levelSelectFont, "Restart", restartButton);

            DrawButton(levelSelectFont, "Quit To Menu", quitButton);
        }

        _spriteBatch.End();
        base.Draw(gameTime);
    }

    // Draws strings in a specific format
    private void DrawShadowedString(SpriteFont font, string value, Vector2 position, Color color)
    {
        _spriteBatch.DrawString(font, value, position + new Vector2(1.0f, 1.0f), Color.Black);
        _spriteBatch.DrawString(font, value, position, color);
    }

    // Draws buttons in a specific format
    private void DrawButton(SpriteFont font, string value, Rectangle button)
    {
        Vector2 position = new Vector2(button.X, button.Y);
        Rectangle outline = new Rectangle(button.X - 1, button.Y - 1, button.Width + 2, button.Height + 2);
        _spriteBatch.Draw(Texture, position - new Vector2(1.0f, 1.0f), outline,
            Color.Black,
            0, Vector2.Zero, 1.0f,
            SpriteEffects.None, 0.00001f);
        _spriteBatch.Draw(Texture, position, button,
            Color.White,
            0, Vector2.Zero, 1.0f,
            SpriteEffects.None, 0.00001f);
        DrawShadowedString(font, value, new Vector2(button.X + 10, button.Y + 10), Color.Black);
    }

    private void LoadLevel(String level)
    {
        // Load level
        map = new TiledMap(Content.RootDirectory + "/" + level + ".tmx");
        tilesets = map.GetTiledTilesets(Content.RootDirectory + "/");
        tilesetTexture = Content.Load<Texture2D>("spritesheets/lab tileset finished transparent");
        spikeTexture = Content.Load<Texture2D>("spritesheets/32-bit-red-spike-Sheet");
        solidLayer = map.Layers.First(l => l.name == "Solid");
        platformLayer = map.Layers.First(l => l.name == "Platform");
        goalLayer = map.Layers.First(l => l.name == "Goal");
        coinLayer = map.Layers.First(l => l.name == "Coin");
        gravityUpLayer = map.Layers.First(l => l.name == "Gravity Up");
        gravityUpColorLayer = map.Layers.First(l => l.name == "gravityUpColor");
        gravityDownLayer = map.Layers.First(l => l.name == "Gravity Down");
        playerSpawn = map.Layers.First(l => l.name == "Player").objects.First();
        Console.Write(playerSpawn.name);
        flippable = (playerSpawn.name == "Spawn_Flippable");
        boxSpawn = map.Layers.First(l => l.name == "Box").objects.First(o => o.name == "Vase");
        spikeLayer = map.Layers.First(l => l.name == "Spikes");
        // Krutik addition:
        switchLayer = map.Layers.First(l => l.name == "Switch");
        doorLayer = map.Layers.First(l => l.name == "Door");

        Reset();
    }

    private void Reset()
    {
        if (Texture == null)
        {   //create texture to draw with if it does not exist
            Texture = new Texture2D(_graphics.GraphicsDevice, 1, 1);
            Texture.SetData<Color>(new Color[] { Color.White });
        }

        // TODO: add initial player state
        
        if (!levelLoaded.Equals(""))
        {
            levelGravity = 1;
            PlayerSheet = Content.Load<Texture2D>("spritesheets/adventurer-Sheet");
            TileSheet = Content.Load<Texture2D>("spritesheets/tiles");

            Sprite = new Player(1, new Point((int)(playerSpawn.x * tileScale), (int)(playerSpawn.y * tileScale)),
                                   new Point(SpriteSize.X, SpriteSize.Y), 18,
                                   GameBounds, PlayerSheet, Content);

            box = new Box(new Rectangle(0, 0, tileSpriteSize, tileSpriteSize),
                          new Point((int)(boxSpawn.x * tileScale), (int)(boxSpawn.y * tileScale)),
                          new Point(TileSize * 3 / 4, TileSize * 3 / 4), GameBounds);

            // Reset to default
            coinsCollected = 0;
            levelGravity = 1;

            _collisionHandler = new CollisionHandler(GameBounds, Sprite, box, impact);

            MediaPlayer.Volume = 0.3f;
            MediaPlayer.Play(music);
            MediaPlayer.IsRepeating = true;
        }
    }
}

