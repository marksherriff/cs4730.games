<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="32bit_spikes" tilewidth="32" tileheight="32" tilecount="4" columns="4">
 <image source="spritesheets/32-bit-red-spike-Sheet.png" width="128" height="32"/>
</tileset>
