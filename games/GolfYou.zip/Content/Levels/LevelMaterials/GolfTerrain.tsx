<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.0" name="GolfTerrain" tilewidth="32" tileheight="32" tilecount="180" columns="18">
 <transformations hflip="0" vflip="1" rotate="0" preferuntransformed="0"/>
 <image source="tileset.png" width="576" height="320"/>
</tileset>
